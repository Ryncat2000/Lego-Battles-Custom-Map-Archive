This is all of the maps for the kings campaign difficulty mod.
> You will need Crystaltile2 (or similar program) in order to import the .map files into lego battles. 

THIS CAMPAIGN WAS TESTED WITH THE 1.12.2 REBALANCE PATCH AND WAS ABLE TO BE COMPLETED WITHOUT RED BRICKS
>>THIS SHOULD ALSO BE COMPLETABLE WITHOUT THE PATCH BUT I DID NOT TEST IT.

and here is a video tutorial for the .ebp import for the rebalance patch (included here)
[ https://youtu.be/n_GBYU4wpa4 ]
(to import the .map files, just find the "maps" folder instead of the "bp" folder and import the maps with the same names)

If you are unfamiliar with this or need help. Please ask us in the lego battles discord 
[ https://discord.com/invite/6rbhw6Tp3t ]


some notes about the levels
--the difficulty spikes may be inconsistent throught all the levels. but i tried my best to make them more chalanging without being near impossible.
--this is also considerd to be NON CANNON (youll find out why) 
--make sure your at least somewhat familiar with the game before you play this. I dont recomend it as your first experience.

--CK1_2 does not have a .map file because it just kept breaking when i tried to edit it, so its the only vanilla level in this campaign.
--CK1_5 is an unused level, please skip it as there is no .map file for it.
--CK3_2, CK3_3 and CK3_4 are the only ones that need updated minimap files, but will work fine without them