This folder consists of Ryncats "better freeplaymaps"

> Map changes= these are freeplay maps with physical changes to the layout from the origonal game thus isnt truely vanilla

> shipyard removals only= all that these map files do are remove the "shipyard" tag from the Ai's buildings they can produce thus prevent them from spamming transports. Most of these maps were intended for PVE modes against the AI to make them slightly more difficult. with the exeption of dead marsh where it simply fixes the building spawns for player 1 to make them for fair in PVP.


You do NOT have to import the minimap files for most of these, they are simply there in case you want to import it over another map file or for backup since the exporting format for minimaps is imperfect in scale from the origonal game.


[] MAP CHANGES NOTES:
1- BetterPond= remade the entire map to be alot more open ended without the random gravel spots and makeing the layout a close mirror with the exption of the mountains and the pond islands. this also makes the AI build harvesters at the top right and bottom left as alternate bases.

2- Better Entrenched= gave every spawn 4 enterences instead of 3 while also making said enterences a few tiles wider so that the pathfinding doesnt break for your own units. The AI will rush into your trees but they at least attack you now instead of getting stuck on the mountain

18- Better Outbreak= created a giant land bridge that cuts through the middle of the "acid ocean" from top to bottom while also creating a bridge of land from each of the sides on the left and the right. this will allow the AI to actually walk to your base and will no longer spam transports

22- Better Dark Waters= replaced all bridge locations with land to walk across making this map less boat focused but much better for the AI in terms of offence so they dont just get stuck on the rivers found on this map

30- Better Ruthless= an entire map remake to allow spawn 2 to be more fair and balanced for PVE while also removing the usual transport spam that the AI loves to do.


> while for the shipyard removals:
10-Better Kings landing
19-Better Crossover
23-Better Lost Lagoon
25-Better Devils Horn
all remove shipyards from the Ai's buld tags thus no transport spam
29-Better Dead Marsh does the same as above but with better spawn locations for player 1
