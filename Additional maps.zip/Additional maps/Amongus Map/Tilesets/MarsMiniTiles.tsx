<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="MarsMiniTiles" tilewidth="8" tileheight="8" tilecount="1024" columns="16">
 <image source="MarsTileset.png" width="128" height="512"/>
</tileset>
