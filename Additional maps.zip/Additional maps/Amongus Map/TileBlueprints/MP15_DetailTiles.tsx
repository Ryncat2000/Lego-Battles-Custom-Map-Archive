<tileset version="1.10" tiledversion="1.11.0" name="MP15" tilewidth="24" tileheight="16" tilecount="194" columns="20">
  <transformations hflip="0" vflip="0" rotate="0" preferuntransformed="1" />
  <image source="MP15_DetailTiles.png" width="336" height="224" />
  <tile id="0" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="1" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="2" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="3" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="4" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="5" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="6" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="7" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="8" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="9" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="10" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="11" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="12" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="13" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="14" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="15" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="16" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="17" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="18" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="19" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="20" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="21" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="22" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="23" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="24" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="25" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="26" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="27" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="28" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="29" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
      <property name="TreeData" value="1" type="int" />
    </properties>
  </tile>
  <tile id="30" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="31" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="32" type="TypedTile" />
  <tile id="33" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="34" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="35" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="36" type="TypedTile" />
  <tile id="37" type="TypedTile" />
  <tile id="38" type="TypedTile" />
  <tile id="39" type="TypedTile" />
  <tile id="40" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="41" type="TypedTile" />
  <tile id="42" type="TypedTile" />
  <tile id="43" type="TypedTile" />
  <tile id="44" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="45" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="46" type="TypedTile" />
  <tile id="47" type="TypedTile" />
  <tile id="48" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="49" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="50" type="TypedTile" />
  <tile id="51" type="TypedTile" />
  <tile id="52" type="TypedTile" />
  <tile id="53" type="TypedTile" />
  <tile id="54" type="TypedTile" />
  <tile id="55" type="TypedTile" />
  <tile id="56" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="57" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="58" type="TypedTile" />
  <tile id="59" type="TypedTile" />
  <tile id="60" type="TypedTile" />
  <tile id="61" type="TypedTile" />
  <tile id="62" type="TypedTile" />
  <tile id="63" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="64" type="TypedTile" />
  <tile id="65" type="TypedTile" />
  <tile id="66" type="TypedTile" />
  <tile id="67" type="TypedTile" />
  <tile id="68" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="69" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="70" type="TypedTile" />
  <tile id="71" type="TypedTile" />
  <tile id="72" type="TypedTile" />
  <tile id="73" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="74" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="75" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="76" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="77" type="TypedTile" />
  <tile id="78" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="79" type="TypedTile" />
  <tile id="80" type="TypedTile" />
  <tile id="81" type="TypedTile" />
  <tile id="82" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="83" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="84" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
      <property name="TreeData" value="1" type="int" />
    </properties>
  </tile>
  <tile id="85" type="TypedTile" />
  <tile id="86" type="TypedTile" />
  <tile id="87" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="88" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="89" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="90" type="TypedTile" />
  <tile id="91" type="TypedTile" />
  <tile id="92" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="93" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="94" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="95" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="96" type="TypedTile" />
  <tile id="97" type="TypedTile" />
  <tile id="98" type="TypedTile" />
  <tile id="99" type="TypedTile" />
  <tile id="100" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="101" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="102" type="TypedTile" />
  <tile id="103" type="TypedTile" />
  <tile id="104" type="TypedTile" />
  <tile id="105" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="106" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="107" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="108" type="TypedTile" />
  <tile id="109" type="TypedTile" />
  <tile id="110" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="111" type="TypedTile" />
  <tile id="112" type="TypedTile" />
  <tile id="113" type="TypedTile" />
  <tile id="114" type="TypedTile" />
  <tile id="115" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="116" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="117" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="118" type="TypedTile" />
  <tile id="119" type="TypedTile" />
  <tile id="120" type="TypedTile" />
  <tile id="121" type="TypedTile" />
  <tile id="122" type="TypedTile" />
  <tile id="123" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="124" type="TypedTile" />
  <tile id="125" type="TypedTile" />
  <tile id="126" type="TypedTile" />
  <tile id="127" type="TypedTile" />
  <tile id="128" type="TypedTile" />
  <tile id="129" type="TypedTile" />
  <tile id="130" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="131" type="TypedTile" />
  <tile id="132" type="TypedTile" />
  <tile id="133" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="134" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="135" type="TypedTile" />
  <tile id="136" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="137" type="TypedTile" />
  <tile id="138" type="TypedTile" />
  <tile id="139" type="TypedTile" />
  <tile id="140" type="TypedTile" />
  <tile id="141" type="TypedTile" />
  <tile id="142" type="TypedTile" />
  <tile id="143" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="144" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="145" type="TypedTile" />
  <tile id="146" type="TypedTile" />
  <tile id="147" type="TypedTile" />
  <tile id="148" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="149" type="TypedTile">
    <properties>
      <property name="TreeData" value="151" type="int" />
    </properties>
  </tile>
  <tile id="150" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="151" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="152" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="153" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="154" type="TypedTile" />
  <tile id="155" type="TypedTile">
    <properties>
      <property name="Type" value="2" type="int" propertytype="TileType" />
      <property name="TreeData" value="255" type="int" />
    </properties>
  </tile>
  <tile id="156" type="TypedTile" />
  <tile id="157" type="TypedTile" />
  <tile id="158" type="TypedTile" />
  <tile id="159" type="TypedTile" />
  <tile id="160" type="TypedTile" />
  <tile id="161" type="TypedTile" />
  <tile id="162" type="TypedTile" />
  <tile id="163" type="TypedTile" />
  <tile id="164" type="TypedTile" />
  <tile id="165" type="TypedTile" />
  <tile id="166" type="TypedTile" />
  <tile id="167" type="TypedTile" />
  <tile id="168" type="TypedTile" />
  <tile id="169" type="TypedTile" />
  <tile id="170" type="TypedTile" />
  <tile id="171" type="TypedTile" />
  <tile id="172" type="TypedTile" />
  <tile id="173" type="TypedTile" />
  <tile id="174" type="TypedTile" />
  <tile id="175" type="TypedTile" />
  <tile id="176" type="TypedTile" />
  <tile id="177" type="TypedTile" />
  <tile id="178" type="TypedTile" />
  <tile id="179" type="TypedTile" />
  <tile id="180" type="TypedTile" />
  <tile id="181" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="182" type="TypedTile" />
  <tile id="183" type="TypedTile" />
  <tile id="184" type="TypedTile" />
  <tile id="185" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="186" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="187" type="TypedTile" />
  <tile id="188" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="189" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="190" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="191" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="192" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
  <tile id="193" type="TypedTile">
    <properties>
      <property name="Type" value="5" type="int" propertytype="TileType" />
    </properties>
  </tile>
</tileset>